package com.example.blelibrary.data;

public class BleWriteState {

    public static final int DATA_WRITE_SINGLE = 1;
}
