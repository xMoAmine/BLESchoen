package com.example.projectschoenfinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NextActivity extends AppCompatActivity {

    TextView dataTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        dataTextView = (TextView) findViewById(R.id.data_text_view);

        Intent intent = getIntent();
        String data = intent.getStringExtra("data");
        dataTextView.setText("Data Received: " + data);
    }

}


